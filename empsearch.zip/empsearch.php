<html>
<head> 
<style>
#tx{border radius: 10px;background-color: khaki;color: blue;font-size: 14pt;}

#bt{border-radius: 10px;backgroung-color: yellow;color: blueviolet;font-size: 14pt;}
#tab{border-radius: 10px; background-image: linear-gradient(to right,green,white,); color: black; font-size: 14pt;}
body{border-radius: 10px;background-image: linear-gradient(to right,blueviolet,yellow);}
</style>
</head>
<body>
<center>
<h1 id='tab'>Search operation</h1>
<hr>
<table id='tab'>
<form name=f1 action="empsearch.php" method="POST">
<tr><td>Enter ecode:</td>
<td><input type="text"name="t1"id='tx'></td>
<td><input type="submit"name="b1"value="empsearch"id='bt'></td>
</form>
</tr>
</table>

<?php
if(isset($_POST['b1']))
{
$ec=$_POST['t1'];

$con=mysqli_connect("localhost","root","","employee");
if(mysqli_connect_errno())
{
echo "Failed to connect to MySQL:".mysqli_connect_errno();
}
$result=mysqli_query($con,"SELECT * FROM empsal where ecode='$ec' ");


echo"<center>";
echo"<h2>Select query </h2>";
echo"<table border =0 id='tab'>";
echo"<tr bgcolor=khaki>";
echo"<th>empcode</th>";
echo"<th>empname </th>";
echo"<th>empsal</th>";
echo"</tr>";

while($row=mysqli_fetch_array($result))
{
echo"<tr>";
echo"<td>".$row['ecode']."</td>";
echo"<td>".$row['ename']."</td>";
echo"<td>".$row['sal']."</td>";
}
echo"</table>";
echo"<center>";
if (mysqli_num_rows($result)==0)
{echo "no record found";}
}
?>